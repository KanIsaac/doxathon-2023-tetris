class TetrisUI:
    async def run(self) -> None:
        raise NotImplementedError
