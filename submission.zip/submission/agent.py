from random import randrange
from typing import Sequence, Union

from tetris import Action, BaseAgent, Board, main

#################################################################
#   Modify the Agent class below to implement your own agent.   #
#   You may define additional methods as you see fit.           #
#################################################################


class Agent(BaseAgent):
    async def play_move(self, board: Board) -> Union[Action, Sequence[Action]]:
        """Makes at least one Tetris move.

        If a sequence of moves is returned, they are made in order
        until the piece lands (with any remaining moves discarded).

        Args:
            board (Board): The Tetris board.

        Returns:
            Union[Action, Sequence[Action]]: The action(s) to perform.
        """
        
        TRANSLATIONS = [
            [],
            [Action.MOVE_LEFT],
            [Action.MOVE_LEFT] * 2,
            [Action.MOVE_LEFT] * 3,
            [Action.MOVE_LEFT] * 4,
            [Action.MOVE_LEFT] * 5,
            [Action.MOVE_RIGHT],
            [Action.MOVE_RIGHT] * 2,
            [Action.MOVE_RIGHT] * 3,
            [Action.MOVE_RIGHT] * 4,
            [Action.MOVE_RIGHT] * 5,
        ]
        ROTATIONS = [
            [],
            [Action.ROTATE_ANTICLOCKWISE],
            [Action.ROTATE_ANTICLOCKWISE] * 2,
            [Action.ROTATE_CLOCKWISE],
            [Action.ROTATE_CLOCKWISE] * 2,
        ]

        MOVES = [m + r + [Action.HARD_DROP] for m in TRANSLATIONS for r in ROTATIONS] + [
            r + m + [Action.HARD_DROP] for m in TRANSLATIONS for r in ROTATIONS
        ]
        
        def score_moves(m):
            newboard = board.with_moves(m).board
            numrows = len(newboard)
            numcols = len(newboard[0])
            
            score = 0  # the score increase

            #Clear Lines
            b = board.with_moves(m)
            if lines := b.find_lines_to_clear():
                score = b.clear_lines(lines)
            
            #Lower max height
            top_non_empty_row = 0
            for i in range(len(newboard)):
                if newboard[i] != [None]*10:
                    top_non_empty_row = i
                    break
            score += top_non_empty_row/2

            #Punish holes
            for i in range(numrows - 1):
                for j in range(numcols):
                    if newboard[i][j] != None:
                        if newboard[i+1][j] == None:
                            score -= 100
                        if (numrows - i) > 2 and newboard[i+2][j] == None:
                            score -= 100
                        
            #Minimise Aggregate Height
            aggregate_height = 0
            for j in range(numcols):
                for i in range(numrows):
                    if newboard[i][j] != None:
                        aggregate_height += i
                        break
            score += aggregate_height * 3

            #Limit Bumpiness
            last = numrows
            aggregate_bump = 0
            for j in range(numcols):
                for i in range(numrows):
                    if newboard[i][j] != None:
                        aggregate_bump += abs(i - last)
                        last = i
                        break
            score -= aggregate_bump
                    

            

            return score

        return max(MOVES, key=score_moves)

        # Perform a random action


SelectedAgent = Agent

#####################################################################
#   This runs your agent and communicates with DOXA over stdio,     #
#   so please do not touch these lines unless you are comfortable   #
#   with how DOXA works, otherwise your agent may not run.          #
#####################################################################

if __name__ == "__main__":
    agent = SelectedAgent()

    main(agent)






        # rotations = [
        #     [Action.ROTATE_ANTICLOCKWISE],
        #     [Action.ROTATE_ANTICLOCKWISE] *2, 
        #     [Action.ROTATE_CLOCKWISE],
        #     [],
        # ]

        # moves = [
        #     [Action.MOVE_LEFT] * 5 + [Action.HARD_DROP],
        #     [Action.MOVE_LEFT] * 4 + [Action.HARD_DROP],
        #     [Action.MOVE_LEFT] * 3 + [Action.HARD_DROP],
        #     [Action.MOVE_LEFT] * 2 + [Action.HARD_DROP],
        #     [Action.MOVE_LEFT] * 1 + [Action.HARD_DROP],
        #     [Action.HARD_DROP],
        #     [Action.MOVE_RIGHT] * 1 + [Action.HARD_DROP],
        #     [Action.MOVE_RIGHT] * 2 + [Action.HARD_DROP],
        #     [Action.MOVE_RIGHT] * 3 + [Action.HARD_DROP],
        #     [Action.MOVE_RIGHT] * 4 + [Action.HARD_DROP],
        #     [Action.MOVE_RIGHT] * 5 + [Action.HARD_DROP],
        # ]
        
        # newboard = []
        # bestrow = 0
        # bestmove = []

        # for currentrotation in rotations:
        #     for currentmove in moves:
        #         movecombo = currentrotation + currentmove
        #         newboard = board.with_moves(movecombo)
        #         rowcounter = 0
        #         top_non_empty_row = 0
        #         for row in newboard:
        #             if row != [None]*10:
        #                 top_non_empty_row = rowcounter
        #                 break
        #             rowcounter += 1
                    
        #         if rowcounter > bestrow:
        #             bestrow = rowcounter
        #             bestmove = movecombo

        # return bestmove




        # def score_moves(m):
        #     newboard = board.with_moves(m)
        #     score = 0  # the score increase
            
        #     b = board.with_moves(m)
        #     if lines := b.find_lines_to_clear():
        #         score = b.clear_lines(lines)
            
        #     top_non_empty_row = 0
        #     for i in newboard:
        #         if newboard[i] != [None]*10:
        #             top_non_empty_row = i
        #             break
        #     score += top_non_empty_row

        #     return -score